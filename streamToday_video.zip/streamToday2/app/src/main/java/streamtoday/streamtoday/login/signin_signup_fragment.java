package streamtoday.streamtoday.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import streamtoday.streamtoday.R;

/**
 * Fragment of buttons to sign in or to sign up
 */

public class signin_signup_fragment extends Fragment implements View.OnClickListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();

        // Get the buttons view
        View v = getView();
        Button signup_button = (Button) v.findViewById(R.id.signup_button);
        signup_button.setOnClickListener(this);
        Button signin_button = (Button) v.findViewById(R.id.signin_button);
        signin_button.setOnClickListener(this);
    }

    /**
     * Inflate the layout for this fragment
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sign_main, container, false);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            // If sign in, replace the actual fragment for sign in's fragment
            case R.id.signin_button:
                Fragment fragment = new signin();
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_main, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                fragmentTransaction.commit();
                break;
            // If sign up, start a new activity
            case R.id.signup_button:
                Intent signup_intent = new Intent(getActivity(), signup.class);
                startActivity(signup_intent);
                break;
        }
    }
}
