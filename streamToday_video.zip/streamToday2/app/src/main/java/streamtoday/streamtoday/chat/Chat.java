package streamtoday.streamtoday.chat;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import e.marcelo.androidutils.DatabaseAccess;
import streamtoday.streamtoday.Connection;
import streamtoday.streamtoday.R;
import streamtoday.streamtoday.SessionManager;

public class Chat extends AppCompatActivity implements View.OnClickListener {

    private FirebaseListAdapter<ChatAdapter> adapter;
    private RelativeLayout main_layout;
    private FloatingActionButton fab;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference root = FirebaseDatabase.getInstance().getReference().getRoot();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        main_layout = (RelativeLayout)findViewById(R.id.chat_main_layout);
        fab = (FloatingActionButton)findViewById(R.id.send_msg_button);
        fab.setOnClickListener(this);

/*
        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser()==null){
                    //start sign in activity
                }
            }
        }
*/
        //this must be done in a assync thread
        //sign in the firebase
        auth = FirebaseAuth.getInstance();

        DatabaseReference teste = root.child("random");
        root.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("ram").exists()){
                }else{
                    Map<String, Object> map = new HashMap<>();
                    map.put("ram", "");
                    root.updateChildren(map);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        Connection connection = new Connection(this);
        connection.execute("chat");
        new Handler().post(new Runnable() {
            @Override
            public void run() {

         /*       String tokenI = "";
                String result = "";
                try {
                    SessionManager sessionManager = new SessionManager(getApplicationContext());
                    List<String> fields = sessionManager.getLoginFields();
                    String identifier = fields.get(0);
                    tokenI = fields.get(1);
                    String signup_url = "http://supremyum.com/Marberdia/android/login/getEmail.php";
                    URL url = new URL(signup_url);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setDoOutput(true);
                    httpURLConnection.setDoInput(true);
                    OutputStream outputStream = httpURLConnection.getOutputStream();
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                    String post_data = URLEncoder.encode("identifier", "UTF-8")+"="+URLEncoder.encode(identifier)+"&"
                            + URLEncoder.encode("tokenI", "UTF-8")+"="+URLEncoder.encode(tokenI);
                    bufferedWriter.write(post_data);
                    bufferedWriter.flush();
                    bufferedWriter.close();
                    outputStream.close();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                    //    String result = "";
                    String line = "";
                    while((line = bufferedReader.readLine())!= null){
                        result += line;
                    }
                    bufferedReader.close();
                    inputStream.close();
                    httpURLConnection.disconnect();
                } catch (IOException e) {
                    e.printStackTrace();
                }finally{
                    JSONObject jsonResult = null;
                    try {
                        jsonResult = new JSONObject(result);
                        String resultReturn = jsonResult.getString("return");
                        if(resultReturn.equals("true")){
                            String email = jsonResult.getString("email");
                            auth.signInWithEmailAndPassword(email, tokenI).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        Toast.makeText(Chat.this, "Authenticantion problem", Toast.LENGTH_LONG).show();
                                    }else{
                                        displayChatMessage();
                                    }
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }*/
            }
        });
    }

    @Override
    public void onClick(View view) {
        //send message into firebase
        if(view.getId()==R.id.send_msg_button){
            EditText input = (EditText)findViewById(R.id.msg_input);
            FirebaseDatabase.getInstance().getReference().child("test").push().setValue(new ChatAdapter(input.getText().toString(),
                    FirebaseAuth.getInstance().getCurrentUser().getEmail()));
            input.setText("");
        }
    }

    public void displayChatMessage(){
        ListView listOfMessage = (ListView)findViewById(R.id.list_message);
        adapter = new FirebaseListAdapter<ChatAdapter>(this,ChatAdapter.class,R.layout.chat_list_item,FirebaseDatabase.getInstance().getReference().child("test")) {
            @Override
            protected void populateView(View v, ChatAdapter model, int position) {
                //Get references to the views of list_item.xml
                TextView messageText, messageUser, messageTime;
                messageText = (TextView) v.findViewById(R.id.message_text);
                messageUser = (TextView) v.findViewById(R.id.message_user);
                messageTime = (TextView) v.findViewById(R.id.message_time);

                messageText.setText(model.getMessageText());
                messageUser.setText(model.getMessageUser());
                messageTime.setText(DateFormat.format("dd-MM-yyyy (HH:mm:ss)", model.getMessageTime()));

            }
        };
        listOfMessage.setAdapter(adapter);
    }
}

