package streamtoday.streamtoday;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import java.io.Serializable;

public class Contact implements Parcelable, Serializable,   Comparable<Contact> {

    private String name;
    private String nickname;
    private int id;
//    private static int last_id = 0;

    public Contact(String name){
      //  model aux = new model();
        this.name = name;
        this.nickname = null;

     //   aux.setLastContactId(this.id++);
    }

    public void setId(int id){this.id = id;}
    protected Contact(Parcel in) {
        this.name = in.readString();
        this.nickname = in.readString();
        this.id = in.readInt();
    }

    public static final Creator<Contact> CREATOR = new Creator<Contact>() {
        @Override
        public Contact createFromParcel(Parcel in) {
            return new Contact(in);
        }

        @Override
        public Contact[] newArray(int size) {
            return new Contact[size];
        }
    };

    public void setName(String name){this.name = name;}
    public void setNickName(String nickName){this.nickname = nickName;}
    public String getName(){return this.name;}
    public String getNickname(){return this.nickname;}
    public int getId(){return this.id;}

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeString(nickname);
        parcel.writeInt(id);
    }

    @Override
    public int compareTo(@NonNull Contact contact) {
        return this.name.compareTo(contact.name);
    }
}
