package e.marcelo.androidutils;

import android.content.res.Resources;

public abstract class FormatConverter {

    /**
     *  Convert Density-Pixels (DP) to Pixels (Px)
     */
    public static int dpToPx(int dp){
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    /**
     *  Convert Pixels (Px) to Density-Pixels (DP)
     */
    public static int pxToDp(int px){
        return (int) (px / Resources.getSystem().getDisplayMetrics().density);
    }

}
