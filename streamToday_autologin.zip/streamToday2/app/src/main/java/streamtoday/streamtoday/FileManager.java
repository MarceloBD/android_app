package streamtoday.streamtoday;


import android.app.Activity;
import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class FileManager {

    public void saveFile(String filename, Serializable object, Context context){
        try {
            FileOutputStream file_object_stream = context.openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream object_stream = new ObjectOutputStream(file_object_stream);
            object_stream.writeObject(object);
            object_stream.close();
            file_object_stream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Serializable loadFile(String filename, Context context){
        Serializable obj_read = null;
        try{
            FileInputStream file_object_stream = context.openFileInput(filename);
            ObjectInputStream object_stream = new ObjectInputStream(file_object_stream);
            obj_read = (Serializable) object_stream.readObject();
            object_stream.close();
            file_object_stream.close();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            return obj_read;
        }

    }
}
