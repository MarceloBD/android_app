package streamtoday.streamtoday;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Marcelo on 10/01/2018.
 */

public class SessionManager {

    private SharedPreferences sharedPreferences;
    private Context context;
    private int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "Pref";
    private SharedPreferences.Editor editor;
    private static final String USER_LOGGED = "USER LOGGED";


    public SessionManager(Context context){
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = sharedPreferences.edit();
    }

    public void createLogin(String identifier, String tokenI){
        editor.putBoolean(USER_LOGGED, true);
        editor.putString("identifier", identifier);
        editor.putString("tokenI", tokenI);
        editor.commit();
    }

    public boolean checkLogin(){
        return sharedPreferences.getBoolean(USER_LOGGED,false);
    }

    public List<String> getLoginFields(){
        List<String> fields = new ArrayList<>();
        fields.add(sharedPreferences.getString("identifier",null));
        fields.add(sharedPreferences.getString("tokenI", null));
        return fields;
    }

    public void deleteLogin(){
        editor.putBoolean(USER_LOGGED, false);
        editor.commit();
    }
}



