package streamtoday.streamtoday;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class model implements Serializable {

    private List<Contact> contacts;
    private int last_contact_id = 0;

    public model(){
        contacts = new ArrayList<>();
        last_contact_id = 0;
    }

    public int getLastContactId(){return last_contact_id;}
    public void setLastContactId(int last_contact_id){this.last_contact_id = last_contact_id;}

    public void addContact(Contact new_contact){
        last_contact_id++;
        new_contact.setId(last_contact_id);
        contacts.add(new_contact);
        Collections.sort(contacts);
    }

    public List<Contact> getContacts(){
        return contacts;
    }

    public void deleteContact(int contact){
        for(int i=0;i<contacts.size();i++) {
            if(contacts.get(i).getId()==contact)
                contacts.remove(i);
        }
    }

    public Contact findContact(int id){
        for(int i=0;i<contacts.size();i++)
            if(contacts.get(i).getId()==id)
                return contacts.get(i);
        return null;
    }

}
