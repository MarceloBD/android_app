package streamtoday.streamtoday.main;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;

import java.util.Calendar;

import streamtoday.streamtoday.R;
import streamtoday.streamtoday.SessionManager;
import streamtoday.streamtoday.homeActivity;
import streamtoday.streamtoday.login.signin_signup;

public class mainActivity extends AppCompatActivity {
    /**
     * Time for the start of the homeActivity
     */
    private static int SPLASH_TIME_OUT = 4000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onStart() {
        super.onStart();
        SessionManager sessionManager = new SessionManager(this);
        long time = Calendar.getInstance().getTimeInMillis();                   // This should be resorted
        final long wait = Calendar.getInstance().getTimeInMillis()-time+4000;
        if(sessionManager.checkLogin()){
            // Call home screen activity
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent homeIntent = new Intent(mainActivity.this, homeActivity.class);
                    startActivity(homeIntent);
                    finish();
                }
            }, wait);
        }else {
            // Call login activity
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent loginIntent = new Intent(mainActivity.this, signin_signup.class);
                    startActivity(loginIntent);
                    finish();
                }
            }, wait);
        }
    }

}
