package streamtoday.streamtoday;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;



public class sign_main extends Fragment implements View.OnClickListener {



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
        View v = getView();
        Button signup_button = (Button) v.findViewById(R.id.signup_button);
        signup_button.setOnClickListener(this);

        Button signin_button = (Button) v.findViewById(R.id.signin_button);
        signin_button.setOnClickListener(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_sign_main, container, false);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.signin_button:
                Fragment fragment = new signin();
                FragmentManager fragmentManager = getFragmentManager();

       //         fragmentTransaction.add(R.id.fragment_container, fragment);
    //            fragmentManager.beginTransaction().remove(this).commit();

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                 fragmentTransaction.replace(R.id.fragment_main, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                fragmentTransaction.commit();
                break;
            case R.id.signup_button:
                Intent signup_intent = new Intent(getActivity(), Login.class);
                startActivity(signup_intent);
                break;
        }
    }



}
