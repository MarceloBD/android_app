package streamtoday.streamtoday;

import android.app.Activity;
import android.app.AlertDialog;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;

import e.marcelo.androidutils.DatabaseAccess;
import streamtoday.streamtoday.chat.Chat;
import streamtoday.streamtoday.login.signup;
import streamtoday.streamtoday.login.signin;
import streamtoday.streamtoday.login.signin_signup;

import static android.os.Debug.waitForDebugger;

/**
 * Created by Marcelo on 06/01/2018.
 */

public class Connection extends AsyncTask<String,Void,String> {

    AlertDialog alertDialog;
    Context context;

    public Connection (Context context){
        this.context = context;
    }
    private String type;

    private FirebaseAuth auth;

    @Override
    protected String doInBackground(String... strings) {
        type = strings[0];
        String result = "";
        if(type.equals("signup")) {
            try {
                String signup_url = "http://supremyum.com/Marberdia/android/login/signup.php";
                URL url = new URL(signup_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user", "UTF-8")+"="+URLEncoder.encode(strings[1])+"&"
                        + URLEncoder.encode("pass", "UTF-8")+"="+URLEncoder.encode(strings[2])+"&"
                        + URLEncoder.encode("email", "UTF-8")+"="+URLEncoder.encode(strings[3])+"&"
                        + URLEncoder.encode("name", "UTF-8")+"="+URLEncoder.encode(strings[4])+"&"
                        + URLEncoder.encode("nickname", "UTF-8")+"="+URLEncoder.encode(strings[5]);
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String line = "";
                while((line = bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }finally{
                return result;
            }

        }
        else if(type.equals("signin")){

            try {
                String signup_url = "http://supremyum.com/Marberdia/android/login/signin.php";
                URL url = new URL(signup_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user", "UTF-8")+"="+URLEncoder.encode(strings[1])+"&"
                        + URLEncoder.encode("pass", "UTF-8")+"="+URLEncoder.encode(strings[2]);
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            //    String result = "";
                String line = "";
                while((line = bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }finally{
                return result;
            }

        }else if(type.equals("chat")){
            SessionManager sessionManager = new SessionManager(context);
            List<String> fields = sessionManager.getLoginFields();
            String identifier = fields.get(0);
            String tokenI = fields.get(1);
            String url = "http://supremyum.com/Marberdia/android/login/getEmail.php";
            List<String> data = Arrays.asList(identifier,tokenI);
            List<String> var_names = Arrays.asList("identifier","tokenI");
            result = DatabaseAccess.postPHP(data,var_names,url);
        }
        return result;
    }

    @Override
    protected void onPreExecute(){
    }

    @Override
    protected void onPostExecute(String result){

        if(type.equals("signup")){
            String message = "Fail";
            ((signup)context).showProgress(false);
            alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Sign Up status");
            if(result.equals("true"))
                message = "Sucess";
            alertDialog.setMessage(message);
            alertDialog.show();
            if(result.equals("true")){
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ((Activity)context).finish();
                    }
                },1500);
            }else {
                //if not signed up
            }
        } else if(type.equals("signin")){
            String message = "Fail";
            Fragment fragment = ((signin_signup)context).getSupportFragmentManager().findFragmentById(R.id.fragment_main);
            ((signin)fragment).showProgress(false);
            alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Sign In status");


            try {
                JSONObject jsonResult = new JSONObject(result);

                String resultReturn = jsonResult.getString("return");

                if(resultReturn.equals("true")){
                    message = "Sucess";
                    String identifier = jsonResult.getString("identifier");
                    String tokenI = jsonResult.getString("tokenI");
                    String email = jsonResult.getString("email");
                    SessionManager sessionManager = new SessionManager(context);
                    sessionManager.createLogin(identifier, tokenI);

                    //must check error in database
                    auth = FirebaseAuth.getInstance();
                    auth.createUserWithEmailAndPassword(email, tokenI).addOnCompleteListener( new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            waitForDebugger();
                            //Log.d(TAG, "Authentication successful");
                            if (!task.isSuccessful()) {
                                Toast.makeText(context, "Authentication failed.",  Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
                alertDialog.setMessage(message);
                alertDialog.show();
                if(resultReturn.equals("true")) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent = new Intent((Activity)context, homeActivity.class);
                            ((Activity)context).startActivity(intent);
                            ((Activity) context).finish();
                        }
                    }, 1500);
                }
                else{
                    //if not signed in
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }else if(type.equals("chat")){
            SessionManager sessionManager = new SessionManager(context);
            List<String> fields = sessionManager.getLoginFields();
            String identifier = fields.get(0);
            String tokenI = fields.get(1);
            List<String> result_list = DatabaseAccess.JsonToList(result, Arrays.asList("return"));
            if(result_list.get(0).equals("true")){
                String email = DatabaseAccess.JsonToList(result, Arrays.asList("email")).get(0);
                auth = FirebaseAuth.getInstance();
                auth.signInWithEmailAndPassword(email, tokenI).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(context, "Authenticantion problem", Toast.LENGTH_LONG).show();
                        }else{
                            ((Chat)context).displayChatMessage();
                        }
                    }
                });
            }
        }
    }
}
