package streamtoday.streamtoday;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class ContactProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_profile);


     //   LayoutInflater layoutInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    //    View ab_view = layoutInflater.inflate(R.layout.navigation_action,null);

        Toolbar main_toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(main_toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.back_icon);

        Contact contact = getIntent().getParcelableExtra("contact_clicked");

        TextView name = (TextView) findViewById(R.id.contact_profile_name);
        name.setText(contact.getName());

        TextView nickname = (TextView) findViewById(R.id.contact_profile_nickname);
        nickname.setText(contact.getNickname());

        TextView main_view = (TextView) findViewById(R.id.contact_profile_main);
        main_view.setText(contact.getName());

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case android.R.id.home:
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
