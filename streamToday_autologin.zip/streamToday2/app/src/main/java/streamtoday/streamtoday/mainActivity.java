package streamtoday.streamtoday;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;

import java.util.Calendar;
import java.util.Date;

public class mainActivity extends AppCompatActivity {
    /**
     * Time for the start of the homeActivity
     */
    private static int SPLASH_TIME_OUT = 4000;

    private int start_sign;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        start_sign = 0;
        setContentView(R.layout.activity_main);

    }

    @Override
    public void onStart() {
        super.onStart();

        SessionManager sessionManager = new SessionManager(this);
        long time = Calendar.getInstance().getTimeInMillis();
        final long wait = Calendar.getInstance().getTimeInMillis()-time+4000;
        if(sessionManager.checkLogin()){
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent homeIntent = new Intent(mainActivity.this, homeActivity.class);
                    startActivity(homeIntent);
                    finish();
                }
            }, wait);
        }else {
            // call the new acvitiy
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Intent homeIntent = new Intent(mainActivity.this, homeActivity.class);
                    // startActivity(homeIntent);
                    Intent loginIntent = new Intent(mainActivity.this, signin_signup.class);
                    startActivity(loginIntent);
                    finish();
                }
            }, wait);

        }
    }

}
