package streamtoday.streamtoday.login;



import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import streamtoday.streamtoday.R;

/**
 * Activity used to call fragments that will occupy the whole screen
 */
public class signin_signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin_signup);

        // Begin fragment in the activity
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        signin_signup_fragment fragment = new signin_signup_fragment();
        fragmentTransaction.replace(R.id.fragment_main,  fragment);
        fragmentTransaction.commit();
    }

}
