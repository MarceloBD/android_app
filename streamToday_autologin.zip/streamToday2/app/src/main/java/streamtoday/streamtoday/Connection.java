package streamtoday.streamtoday;

import android.app.Activity;
import android.app.AlertDialog;

import android.content.Context;
import android.content.Intent;
import android.media.MediaCas;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.view.inputmethod.InputMethodManager;
import android.support.v4.app.Fragment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by Marcelo on 06/01/2018.
 */

public class Connection extends AsyncTask<String,Void,String> {

    AlertDialog alertDialog;
    Context context;

    public Connection (Context context){
        this.context = context;
    }
    private String type;

    @Override
    protected String doInBackground(String... strings) {
        type = strings[0];
        String result = "";
        if(type.equals("signup")) {
            try {
                String signup_url = "http://supremyum.com/Marberdia/android/login/signup.php";
                URL url = new URL(signup_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user", "UTF-8")+"="+URLEncoder.encode(strings[1])+"&"
                        + URLEncoder.encode("pass", "UTF-8")+"="+URLEncoder.encode(strings[2])+"&"
                        + URLEncoder.encode("email", "UTF-8")+"="+URLEncoder.encode(strings[3])+"&"
                        + URLEncoder.encode("name", "UTF-8")+"="+URLEncoder.encode(strings[4])+"&"
                        + URLEncoder.encode("nickname", "UTF-8")+"="+URLEncoder.encode(strings[5]);
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String line = "";
                while((line = bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }finally{
                return result;
            }

        }
        else if(type.equals("signin")){

            try {
                String signup_url = "http://supremyum.com/Marberdia/android/login/signin.php";
                URL url = new URL(signup_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("user", "UTF-8")+"="+URLEncoder.encode(strings[1])+"&"
                        + URLEncoder.encode("pass", "UTF-8")+"="+URLEncoder.encode(strings[2]);
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            //    String result = "";
                String line = "";
                while((line = bufferedReader.readLine())!= null){
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            } catch (IOException e) {
                e.printStackTrace();
            }finally{
                return result;
            }

        }
        return null;
    }

    @Override
    protected void onPreExecute(){
    }

    @Override
    protected void onPostExecute(String result){

        if(type.equals("signup")){
            String message = "Fail";
            ((Login)context).showProgress(false);
            alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Sign Up status");
            if(result.equals("true"))
                message = "Sucess";
            alertDialog.setMessage(message);
            alertDialog.show();
            if(result.equals("true")){
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ((Activity)context).finish();
                    }
                },1500);
            }else {
                //if not signed up
            }
        } else if(type.equals("signin")){
            String message = "Fail";
            Fragment fragment = ((signin_signup)context).getSupportFragmentManager().findFragmentById(R.id.fragment_main);
            ((signin)fragment).showProgress(false);
            alertDialog = new AlertDialog.Builder(context).create();
            alertDialog.setTitle("Sign In status");


            try {
                JSONObject jsonResult = new JSONObject(result);

                String resultReturn = jsonResult.getString("return");

                if(resultReturn.equals("true")){
                    message = "Sucess";
                    String identifier = jsonResult.getString("identifier");
                    String tokenI = jsonResult.getString("tokenI");
                    SessionManager sessionManager = new SessionManager(context);
                    sessionManager.createLogin(identifier, tokenI);
                }
                alertDialog.setMessage(message);
                alertDialog.show();
                if(resultReturn.equals("true")) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Intent intent = new Intent((Activity)context, homeActivity.class);
                            ((Activity)context).startActivity(intent);
                            ((Activity) context).finish();
                        }
                    }, 1500);
                }
                else{
                    //if not signed in
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
