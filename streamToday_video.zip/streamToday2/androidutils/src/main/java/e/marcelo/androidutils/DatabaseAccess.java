package e.marcelo.androidutils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Marcelo on 18/01/2018.
 */

public class DatabaseAccess {

    /**
     * Post data in php script
     * @param url_string URL as string
     * @param data Data to be posted in php
     * @param var_names Variable names of the data. Both list must have the same size
     * @return Result string echoed by php
     */
    public static String postPHP(List<String> data, List<String> var_names, String url_string){
        String result = "";
        try {
            URL url = new URL(url_string);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            String post_data = "";
            post_data += URLEncoder.encode(var_names.get(0), "UTF-8") + "=" + URLEncoder.encode(data.get(0));
            for(int i=1;i<data.size();i++) {
                post_data += "&" + URLEncoder.encode(var_names.get(i), "UTF-8") + "=" + URLEncoder.encode(data.get(i));
            }
            bufferedWriter.write(post_data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
            String line = "";
            while((line = bufferedReader.readLine())!= null){
                result += line;
            }
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
       //     return result;
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            return result;
    }
   //     return result;
}

    /**
     * Convert a json string to a Java list
     * @param json_string String as json to be converted
     * @param var_names Name of the variables inside the Json
     * @return List of strings converted
     */
    public static List<String> JsonToList(String json_string, List<String> var_names) {
    List<String> result = new ArrayList<>();
    try {
        JSONObject jsonResult = new JSONObject(json_string);
        for(int i=0;i<var_names.size();i++){
            result.add(jsonResult.getString(var_names.get(i)));
        }
    } catch (JSONException e) {
        e.printStackTrace();
    }
    finally {
        return result;
    }
}


}
