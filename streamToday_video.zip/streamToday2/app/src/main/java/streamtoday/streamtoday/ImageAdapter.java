package streamtoday.streamtoday;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.Nullable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import streamtoday.streamtoday.contacts.Contact;

public class ImageAdapter extends BaseAdapter implements Filterable {

    /**
     * Can be transformed in a list of objects
     */
    private Context context;
 //   private Integer button_id;
 //   private List<String> names;
    private SparseBooleanArray selected_ids;
 //   private List<String> orig_names;
    private List<Contact> orig_contacts;
    private List<Contact> contacts;

    public ImageAdapter(Context context){
        this.context = context;
     //   button_id = ;
      //  names = new ArrayList<>();
        selected_ids = new SparseBooleanArray();
        contacts = new ArrayList<>();
    }

/*
    public void addButton_ids(Contact new_contact){
        LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.single_item, null);
        TextView grid_single_view = (TextView) view.findViewById(R.id.grid_single_view);
        names.add(new_contact.getName());

        button_ids.add(R.id.grid_single_view);
    }
*/
    @Override
    public int getCount() {
        return contacts.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        Activity activity = (Activity) context;
        if (view == null){
            view = new View (context);
            view = layoutInflater.inflate(R.layout.single_item, null);
        }
        TextView grid_single_view = (TextView)view.findViewById(R.id.grid_single_view);
        grid_single_view.setText(contacts.get(i).getName());

        if(selected_ids.get(i)){
            grid_single_view.setBackgroundResource(R.color.colorPrimary);
        }else
            grid_single_view.setBackgroundResource(R.color.white);
        return view;
    }

    @Nullable
    @Override
    public CharSequence[] getAutofillOptions() {
        return new CharSequence[0];
    }

    public SparseBooleanArray getSelectedIds(){return selected_ids;}

    public void selectView(int position, boolean value){
        if(!value) {
            selected_ids.put(position, true);

        }
        else {
            selected_ids.delete(position);
        }
        notifyDataSetChanged();
    }

    public void removeSelection(){
        selected_ids = new SparseBooleanArray();
        notifyDataSetChanged();
    }

    public void toggleSelection(int position){
        selectView(position, selected_ids.get(position));
    }

    public int findId(int position){
        return contacts.get(position).getId();
     //   reloadContacts();
   //     button_ids.remove(position);
      //  contacts.remove(position);
    //    notifyDataSetChanged();
    }



    public void setContacts(List<Contact> contacts){
        this.contacts = contacts;
        notifyDataSetChanged();
    }

    public void reloadContacts(){
        if(orig_contacts==null)
            return;
        contacts = new ArrayList<> (orig_contacts);
        orig_contacts = null;
    }

    public Filter getFilter() {
        return new Filter() {

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                final FilterResults filter_result = new FilterResults();
                final List<Contact> contact_results = new ArrayList<>();
                if ( orig_contacts == null)
                    orig_contacts = contacts;
                if (constraint != null) {
                    if (orig_contacts != null && orig_contacts.size() > 0) {
                        for (final Contact g : orig_contacts) {
                            if (g.getName().toLowerCase()
                                    .contains(constraint.toString().toLowerCase()))
                                contact_results.add(g);
                        }
                    }
                    filter_result.values = contact_results;
                }
                return filter_result;
            }

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint,
                                          FilterResults results) {
                contacts = (ArrayList<Contact>) results.values;
                notifyDataSetChanged();
            }
        };
    }

}
