package streamtoday.streamtoday;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

public class homeActivity extends AppCompatActivity implements View.OnClickListener, AbsListView.MultiChoiceModeListener, SearchView.OnQueryTextListener, AdapterView.OnItemClickListener, NavigationView.OnNavigationItemSelectedListener {

    ActionMode delete_action;
    //boolean yes_no;
    private boolean config_change;
    private ImageAdapter imageAdapter;
    private model model;
    private GridView gridView;
    private SearchView searchView;
    /**
     * Manage the side bar menu
     */
    private DrawerLayout main_drawer_layout;
    private ActionBarDrawerToggle main_toggle;
    /**
     * Top toolbar
     */
    private Toolbar main_toolbar;
    /**
     * Add new contacts button
     */
    private ImageButton add_button;

    private final int REQUEST_CODE_ADD_CONTACT = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageAdapter = new ImageAdapter(this);

      //  yes_no = false;
        model = (model)new FileManager().loadFile("save", this);
        if(model==null)
            model = new model();
        else {
            imageAdapter.setContacts(model.getContacts());
    /*        GridView gridView = (GridView)findViewById(R.id.gridView);
            gridView.setAdapter(imageAdapter);
            gridView.setChoiceMode(GridView.CHOICE_MODE_MULTIPLE_MODAL);
            gridView.setMultiChoiceModeListener(this);
      */  }
      /*  if(savedInstanceState==null) {
           // model = new model();
            imageAdapter = new ImageAdapter(this);
        }
        else{
         //   model = (model)savedInstanceState.getSerializable("model");
            imageAdapter = (ImageAdapter)savedInstanceState.getSerializable("image");
        }*/
        setContentView(R.layout.activity_home);

        main_toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(main_toolbar);


        LayoutInflater layoutInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View search_view = layoutInflater.inflate(R.layout.search_view,null);
        main_toolbar.addView(search_view.findViewById(R.id.search_view));

        main_drawer_layout = (DrawerLayout) findViewById(R.id.main_drawer_layout);
        main_toggle = new ActionBarDrawerToggle(this, main_drawer_layout, R.string.open, R.string.close);
        main_drawer_layout.addDrawerListener(main_toggle);
        main_toggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        add_button = (ImageButton)findViewById(R.id.main_add_button);
        add_button.setOnClickListener(this);

        NavigationView navigationView = (NavigationView)findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    public void onStart() {
        super.onStart();
        gridView = (GridView) findViewById(R.id.gridView);

        gridView.setAdapter(imageAdapter);
        gridView.setTextFilterEnabled(true);
        gridView.setChoiceMode(GridView.CHOICE_MODE_MULTIPLE_MODAL);
        gridView.setMultiChoiceModeListener(this);
        gridView.setTextFilterEnabled(false);
        gridView.setOnItemClickListener(this);


        searchView = (SearchView) findViewById(R.id.search_view);

        searchView.setFocusable(false);
        searchView.setIconified(false);
        searchView .setIconifiedByDefault(false);
        searchView.clearFocus();
        searchView.setOnQueryTextListener(this);
        searchView.setSubmitButtonEnabled(true);
        searchView.setQueryHint("Search contacts");

    }
/*
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable("image",  imageAdapter);
    }*/
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Contact new_contact;
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUEST_CODE_ADD_CONTACT && resultCode==Activity.RESULT_OK){
            imageAdapter.reloadContacts();
            new_contact = (Contact)data.getParcelableExtra("new_contact");
            Toast.makeText(homeActivity.this, "Contact added", Toast.LENGTH_SHORT).show();
            if (new_contact!=null) {
                model.addContact(new_contact);
                imageAdapter.setContacts(model.getContacts());
               // imageAdapter.addButton_ids(new_contact);

                GridView gridView = (GridView)findViewById(R.id.gridView);
                gridView.setAdapter(imageAdapter);
                gridView.setChoiceMode(GridView.CHOICE_MODE_MULTIPLE_MODAL);
                gridView.setMultiChoiceModeListener(this);
            }
        }

    }
;
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(main_toggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.main_add_button:
                Intent add_contact_intent = new Intent(homeActivity.this, addContactActivity.class);
                startActivityForResult(add_contact_intent, REQUEST_CODE_ADD_CONTACT);
//

        }
    }


    @Override
    public void onItemCheckedStateChanged(ActionMode actionMode, int i, long l, boolean b) {
        GridView grid_view = (GridView)findViewById(R.id.gridView);
        int checked_count = grid_view.getCheckedItemCount();
        actionMode.setTitle(checked_count + " Selected");
        imageAdapter.toggleSelection(i);
    }

    @Override
    public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
        MenuInflater inflater_menu = actionMode.getMenuInflater();
        inflater_menu.inflate(R.menu.delete_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
        return false;
    }

    @Override
    public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.deleteContact:
                SparseBooleanArray selected = imageAdapter.getSelectedIds();
                new AlertDialog.Builder(this)
                        .setTitle("Delete")
                        .setMessage("Do you really want to delete "+selected.size()+" contacts?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                Toast.makeText(homeActivity.this, "Contacts removed sucessfully", Toast.LENGTH_SHORT).show();
                                SparseBooleanArray selected = imageAdapter.getSelectedIds();
                                for(int i=selected.size()-1;i>=0;i--) {
                                    if (selected.valueAt(i)) {
                                        int key = selected.keyAt(i);
                                        int pos = imageAdapter.findId(key);
                                        model.deleteContact(pos);
                                    }
                                }
                                imageAdapter.setContacts(model.getContacts());
                                delete_action.finish();
                            }})
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                delete_action.finish();
                            }
                        }).show();
                delete_action = actionMode;
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onDestroyActionMode(ActionMode actionMode) {
        imageAdapter.removeSelection();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onStop() {
        new FileManager().saveFile("save", model, this);
        super.onStop();
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
     /*   if (TextUtils.isEmpty(newText)) {
            gridView.clearTextFilter();
        } else {
            gridView.setFilterText(newText);
        }*/
        imageAdapter.getFilter().filter(newText);
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Intent contact_profile_intent = new Intent(homeActivity.this, ContactProfile.class);
        int id = imageAdapter.findId(i);
        Contact contact_clicked = model.findContact(id);
        contact_profile_intent.putExtra("contact_clicked", (Parcelable) contact_clicked);
        startActivity(contact_profile_intent);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.log_out:
                new SessionManager(this).deleteLogin();
                Intent sign = new Intent(homeActivity.this, signin_signup.class);
                startActivity(sign);
                finish();
                return true;
        }


        return false;
    }
}
